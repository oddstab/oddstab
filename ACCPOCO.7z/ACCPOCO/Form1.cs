﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Dapper;

using SQLSERVER_Lib;

namespace ACCPOCO
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void GenerateCode(object sender, EventArgs e)
        {
            try
            {
                string temp = "";
                
                if (string.IsNullOrEmpty(sqlString.Text))
                {
                    return;
                }

                if (string.IsNullOrWhiteSpace(sqlString.SelectedText))
                {
                    temp = sqlString.Text;
                }
                else
                {
                    temp = sqlString.SelectedText;
                    sqlString.DeselectAll();
                }

                SQLHelper sql = new SQLHelper();
                var connStr = sql.GetSqlConnectionString("ERP-1-2");
                using (var conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string code = PocoClassGenerator.GenerateClass(conn, temp, $"{className1.Text}_{className2.Text}_{className3.Text}");
                    var view = new CodeView(code)
                    {
                        StartPosition = FormStartPosition.CenterParent
                    };
                    view.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR " + ex.Message);
                sqlString.Focus();
            }
        }

        private void Paste_Click(object sender, EventArgs e)
        {
            try
            {
                string pasteStr = Clipboard.GetText();

                if (!string.IsNullOrEmpty(pasteStr))
                {
                    sqlString.Clear();
                    sqlString.Text = pasteStr;
                }
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlString.Focus();
        }
    }
}
