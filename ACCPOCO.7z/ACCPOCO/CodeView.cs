﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ACCPOCO
{
    public partial class CodeView : Form
    {
        public CodeView()
        {
            InitializeComponent();
        }

        public CodeView(string codeText)
        {
            InitializeComponent();
            code.Text = codeText;
        }

        private void copy_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(code.Text);
                Text = "已複製！ "+ DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show("複製失敗！ " + ex.Message);
            }
        }
    }
}
